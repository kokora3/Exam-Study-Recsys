# Dataset_Chapter3_4

Dataset สำหรับ Lab บทที่ 3 และ 4

โครงสร้าง:

Dataset_Chapter3_4/
├── data/
│   ├── metadata.csv
│   ├── ratings.csv
│   ├── popularity.csv
│   ├── dataset_manifest.csv
│   ├── images/
│   ├── audio/
│   └── video/
└── figures/
    └── 00_multimodal_overview.png

Google Drive ที่แนะนำ:

/content/drive/MyDrive/Colab Notebooks/Dataset_Chapter3_4/

Notebook:
Import_Dataset_Chapter3_4.ipynb

หมายเหตุ:
- Chapter 3 ใช้ Text จาก genre + synopsis
- Chapter 4 เพิ่ม Image / Audio / Video
- schema จะ normalize genres -> genre อัตโนมัติใน Notebook
