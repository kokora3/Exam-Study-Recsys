# MovieMini-12 Multimodal Lab Package

สร้างจากโครงสร้างเนื้อหา Chapter 3–4 และตัวชี้วัด Chapter 2 สำหรับใช้เป็น Lab สาธิต **Text + Image + Audio + Video**.

## สำคัญ
สื่อภาพ เสียง และวิดีโอใน `data/images`, `data/audio`, `data/video` เป็น **synthetic teaching assets** ที่สร้างขึ้นใหม่เพื่อการทดลองเวกเตอร์ ไม่ใช่โปสเตอร์ เสียง หรือคลิปจากภาพยนตร์จริง และไม่ได้ตั้งใจเลียนแบบงานศิลป์ต้นฉบับ.

## โครงสร้าง
- `data/metadata.csv` — MovieMini-12 + เวกเตอร์สื่อ 3 มิติตามตัวอย่าง Chapter 4
- `data/ratings.csv` — u1–u8
- `data/images/*.png` — 12 ภาพ
- `data/audio/*.wav` — 12 คลิปเสียงสังเคราะห์ (4 วินาที)
- `data/video/*.mp4` — 12 วิดีโอสังเคราะห์ (4 วินาที)
- `notebooks/MovieMini12_Multimodal_Lab.ipynb` — Colab/Python Lab
- `src/dataset_adapter.py` — **ส่วนเฉพาะ Dataset**; เปลี่ยน Dataset ให้แก้ตรงนี้ก่อน
- `src/recsys_core.py` — vector/profile/recommendation ที่ใช้ซ้ำได้
- `src/evaluation.py` — Accuracy + Beyond-Accuracy metrics
- `src/media_features.py` — อ่านคุณลักษณะจาก PNG/WAV/MP4
- `app/gradio_app.py` — GUI แสดง User Profile / Top-K
- `figures/00_multimodal_overview.png` — ภาพรวม Multimodal รวม Text
- `results/evaluation_summary.csv` — ผลทดลองต้นแบบ

## Transformation ที่เน้นใน Lab
1. สร้าง raw vector ของแต่ละ modality
2. เปรียบเทียบ `Raw + L2` กับ `Centering + L2`
3. แสดง pairwise cosine distribution ก่อน/หลัง centering
4. สร้าง User Profile ในปริภูมิเดียวกับ item vector
5. เปรียบเทียบ Text / Image / Audio / Video / Multimodal concat

## Metrics
Ranking/Accuracy: Precision@3, Recall@3, F1@3, HR@3, MRR, MAP@3, nDCG@3, AUC

Beyond-Accuracy: Catalog Coverage, Gini exposure, ILD, Novelty, Calibration

`MAE/RMSE` ไม่คำนวณจาก similarity โดยฝืนแปลงเป็น rating เพราะจะทำให้ความหมายของ metric ผิด; ให้ใช้เมื่อ model มี `predicted_rating` จริง.

## Run
```bash
pip install numpy pandas scipy scikit-learn pillow opencv-python gradio matplotlib
python src/run_experiments.py
python app/gradio_app.py
```

บน Windows ให้นำโฟลเดอร์นี้ไปวางที่ `D:\0000-New-204729` แล้วเปิด notebook ใน Colab/Jupyter.
